# 🍔 Burguer Dely

Projeto **Burguer Dely**, desenvolvido como uma aplicação web de cardápio digital para hamburgueria, com catálogo de produtos, carrinho, checkout, pagamento via PIX e acompanhamento do pedido.

## 📋 Sobre o projeto

O sistema foi estruturado com React + TypeScript e Vite, utilizando componentes modernos e navegação por rotas. A aplicação permite ao cliente consultar o cardápio, selecionar produtos, montar o pedido e avançar para o checkout.

## ✨ Funcionalidades

- 📱 Cardápio digital
- 🍔 Catálogo de hambúrgueres e produtos
- 🛒 Carrinho de compras
- 💳 Checkout com PIX
- 📱 Geração de QR Code PIX
- 📍 Mapa para acompanhamento/localização de entrega
- 🚚 Rastreamento de pedidos
- 🔔 Notificações na interface
- 📱 Interface responsiva

## 🛠️ Tecnologias

- React 18
- TypeScript
- Vite
- Tailwind CSS
- React Router DOM
- Leaflet / React Leaflet
- QRCode
- Lucide React
- Sonner
- Radix UI

## 🚀 Como executar

### 1. Pré-requisitos

Instale o [Node.js](https://nodejs.org/) na versão LTS.

### 2. Instale as dependências

```bash
npm install
```

Ou, se utilizar Bun:

```bash
bun install
```

### 3. Execute em desenvolvimento

```bash
npm run dev
```

Ou:

```bash
bun dev
```

Abra o endereço mostrado pelo Vite no terminal.

### 4. Gerar versão de produção

```bash
npm run build
```

A versão compilada será criada na pasta `dist/`.

## 🔑 Configuração do PIX

A chave PIX utilizada pelo checkout pode ser configurada no arquivo correspondente da página de checkout:

```text
src/pages/Checkout.tsx
```

Substitua a chave de exemplo pela chave PIX utilizada no ambiente do projeto.

## 📁 Estrutura principal

```text
BurguerDely/
├── public/
├── src/
│   ├── components/
│   ├── pages/
│   ├── App.tsx
│   ├── App.css
│   ├── index.css
│   └── main.tsx
├── .gitignore
├── package.json
├── tailwind.config.ts
├── vite.config.ts
└── README.md
```

## 👨‍💻 Projeto

**Burguer Dely**

Desenvolvimento acadêmico / projeto de software.
